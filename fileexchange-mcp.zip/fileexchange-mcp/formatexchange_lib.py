import json
import copy
import os
from datetime import datetime
from typing import Optional


# Default IMS field definitions: (field_name, length, description)
DEFAULT_IMS_FIELDS = [
    ("stationAbbr", 6, "Station Abbreviation"),
    ("offerDateStr", 10, "Date Offered"),
    ("offerTimeStr", 8, "Time Offered"),
    ("otherRailRoad", 4, "Other Railroad"),
    ("printer", 8, "Printer"),
    ("phoneOfNotified", 10, "Phone of Notified"),
    ("phoneOfNotifier", 10, "Phone of Notifier"),
    ("carStationAbbr", 6, "Car Station Abbreviation"),
    ("lastNameOfNotified", 20, "Last Name of Notified"),
    ("lastNameOfNotifier", 20, "Last Name of Notifier"),
    ("comment1", 50, "Comment1"),
    ("comment2", 50, "Comment2"),
]

# Default equipment detail fields per entry: (field_name, length, description)
DEFAULT_EQUIPMENT_FIELDS = [
    ("trackNumber", 4, "Track Number"),
    ("carInitial", 8, "Car Initial"),
    ("carNumber", 6, "Car Number"),
]

DEFAULT_EQUIPMENT_GROUP_NAME = "equipmentDetailList"


def load_config(config_path: str) -> dict:
    """Load IMS field configuration from a JSON file."""
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        raise Exception(f"Error loading config: {str(e)}")


def _match_endpoint_config(config: Optional[dict], endpoint: Optional[str]) -> Optional[dict]:
    """Find the endpoint-specific config by matching endpoint name/URL pattern."""
    if config is None or not endpoint:
        return None
    endpoints = config.get("endpoints", {})
    if not endpoints:
        return None
    # Try exact match first
    for pattern, ep_config in endpoints.items():
        if pattern.lower() == endpoint.lower():
            return ep_config
    # Then substring match
    for pattern, ep_config in endpoints.items():
        if pattern.lower() in endpoint.lower() or endpoint.lower() in pattern.lower():
            return ep_config
    return None


def _get_endpoint_body_format(config: Optional[dict], endpoint: Optional[str]) -> str:
    """Return the body format for the endpoint: 'string' or 'jsonArray'."""
    ep_config = _match_endpoint_config(config, endpoint)
    if ep_config:
        return ep_config.get("bodyFormat", "string")
    return "string"


def _get_fields_from_config(config: Optional[dict] = None, endpoint: Optional[str] = None):
    """Extract field tuples and repeating group from config, or use defaults.
    If config has 'endpoints' mapping, match by endpoint name/URL pattern."""
    if config is None:
        return DEFAULT_IMS_FIELDS, DEFAULT_EQUIPMENT_FIELDS, DEFAULT_EQUIPMENT_GROUP_NAME

    # Check if config has endpoint-specific mappings
    ep_config = _match_endpoint_config(config, endpoint)
    if ep_config:
        # For jsonArray format, use primaryRecord fields
        if ep_config.get("bodyFormat") == "jsonArray":
            primary = ep_config.get("primaryRecord", {})
            return _parse_config_fields(primary)
        return _parse_config_fields(ep_config)

    # Fall back to top-level fields (single-mapping config) or defaultFields
    if config.get("fields"):
        return _parse_config_fields(config)
    if config.get("defaultFields"):
        return _parse_config_fields(config["defaultFields"])

    return DEFAULT_IMS_FIELDS, DEFAULT_EQUIPMENT_FIELDS, DEFAULT_EQUIPMENT_GROUP_NAME


def _parse_config_fields(config: dict):
    """Parse fields and repeating group from a config dict.
    Supports 'skip' flag for filler fields."""
    ims_fields = []
    for f in config.get("fields", []):
        skip = f.get("skip", False)
        ims_fields.append((f["jsonField"], f["length"], f.get("description", ""), skip))

    repeating = config.get("repeatingGroup", {})
    group_name = repeating.get("jsonField", DEFAULT_EQUIPMENT_GROUP_NAME)
    eq_fields = []
    for f in repeating.get("fields", []):
        eq_fields.append((f["jsonField"], f["length"], f.get("description", ""), f.get("skip", False)))

    return ims_fields or DEFAULT_IMS_FIELDS, eq_fields, group_name


def _apply_computed_fields(result: dict, config_section: dict):
    """Apply computed/constant fields from config to the parsed result.
    Supports 'value' (constant) and 'template' (str.format with parsed field values)."""
    for cf in config_section.get("computedFields", []):
        field_name = cf["jsonField"]
        if "value" in cf:
            result[field_name] = cf["value"]
        elif "template" in cf:
            try:
                result[field_name] = cf["template"].format(**result)
            except (KeyError, ValueError):
                result[field_name] = ""


def _parse_fields_from_string(ims_string: str, field_defs: list, skip_fillers: bool = True) -> dict:
    """Parse fields from a fixed-length string using field definitions.
    field_defs: list of (field_name, length, description) or 4-tuple with skip flag."""
    result = {}
    offset = 0
    padded = ims_string.ljust(sum(f[1] for f in field_defs))
    for field_def in field_defs:
        field_name = field_def[0]
        length = field_def[1]
        skip = field_def[3] if len(field_def) > 3 else False
        value = padded[offset:offset + length].strip()
        if not (skip and skip_fillers):
            result[field_name] = value
        offset += length
    return result


def parse_ims_to_json(ims_string: str, config: Optional[dict] = None, endpoint: Optional[str] = None) -> dict:
    """Parse a fixed-length IMS string into a structured JSON dictionary.
    Supports both simple IMS strings and JSON arrays of IMS strings."""
    if not ims_string or len(ims_string.strip()) == 0:
        return {"error": "Empty IMS string provided"}

    ims_fields, eq_fields, group_name = _get_fields_from_config(config, endpoint)
    base_length = sum(f[1] for f in ims_fields)
    eq_entry_length = sum(f[1] for f in eq_fields) if eq_fields else 0

    # Pad the string if it's shorter than base length
    padded = ims_string.ljust(base_length)

    result = _parse_fields_from_string(padded, ims_fields)

    # Apply computed fields from endpoint config
    ep_config = _match_endpoint_config(config, endpoint)
    if ep_config:
        _apply_computed_fields(result, ep_config)

    # Parse repeating group entries (variable count after base fields)
    if eq_fields and eq_entry_length > 0:
        remaining = padded[base_length:]
        entries = []
        while len(remaining) >= eq_entry_length:
            entry = _parse_fields_from_string(remaining[:eq_entry_length], eq_fields)
            if any(v for v in entry.values()):
                entries.append(entry)
            remaining = remaining[eq_entry_length:]
        result[group_name] = entries

    return result


def parse_array_ims_to_json(ims_strings: list, config: Optional[dict] = None, endpoint: Optional[str] = None) -> dict:
    """Parse a JSON array of IMS strings (primary + secondary records).
    Used when bodyFormat is 'jsonArray' in config."""
    if not ims_strings:
        return {"error": "Empty IMS array provided"}

    ep_config = _match_endpoint_config(config, endpoint)
    if not ep_config or ep_config.get("bodyFormat") != "jsonArray":
        # Fallback: just parse the first string
        return parse_ims_to_json(ims_strings[0], config, endpoint)

    # Parse primary record
    primary_cfg = ep_config.get("primaryRecord", {})
    primary_fields = []
    for f in primary_cfg.get("fields", []):
        primary_fields.append((f["jsonField"], f["length"], f.get("description", ""), f.get("skip", False)))

    result = _parse_fields_from_string(ims_strings[0], primary_fields)

    # Apply computed fields
    _apply_computed_fields(result, primary_cfg)

    # Parse secondary records
    sec_cfg = ep_config.get("secondaryRecord", {})
    sec_list_name = sec_cfg.get("jsonField", "secondaryRecords")
    sec_fields = []
    for f in sec_cfg.get("fields", []):
        sec_fields.append((f["jsonField"], f["length"], f.get("description", ""), f.get("skip", False)))

    if sec_fields and len(ims_strings) > 1:
        secondary_entries = []
        for sec_ims in ims_strings[1:]:
            entry = _parse_fields_from_string(sec_ims, sec_fields)
            if any(v for v in entry.values()):
                secondary_entries.append(entry)
        result[sec_list_name] = secondary_entries

    return result


def json_to_ims(json_data: dict, config: Optional[dict] = None, endpoint: Optional[str] = None) -> str:
    """Convert a JSON dictionary back into a fixed-length IMS string."""
    ims_fields, eq_fields, group_name = _get_fields_from_config(config, endpoint)

    ims_string = ""
    for field_name, length, description in ims_fields:
        value = str(json_data.get(field_name, ""))
        ims_string += value.ljust(length)[:length]

    # Append repeating group entries
    for entry in json_data.get(group_name, []):
        for field_name, length, description in eq_fields:
            value = str(entry.get(field_name, ""))
            ims_string += value.ljust(length)[:length]

    return ims_string


def get_ims_field_definitions(config: Optional[dict] = None, endpoint: Optional[str] = None) -> list:
    """Return the IMS field definitions with offsets."""
    ims_fields, eq_fields, group_name = _get_fields_from_config(config, endpoint)

    definitions = []
    offset = 0
    for field_name, length, description in ims_fields:
        definitions.append({
            "field_name": field_name,
            "format": f"A{length}",
            "length": length,
            "offset": offset,
            "description": description,
        })
        offset += length

    # Add repeating group field definitions
    if eq_fields:
        eq_offset = 0
        for field_name, length, description in eq_fields:
            definitions.append({
                "field_name": f"{group_name}[].{field_name}",
                "format": f"A{length}",
                "length": length,
                "offset": offset + eq_offset,
                "description": f"{group_name} - {description} (repeating)",
            })
            eq_offset += length

    return definitions


def read_postman_collection(file_path: str) -> dict:
    """Read a Postman collection file and return structured data."""
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        collection_name = data.get("info", {}).get("name", "Unknown")
        items = data.get("item", [])

        requests = []
        for item in items:
            request_info = item.get("request", {})
            request_data = {
                "name": item.get("name", ""),
                "method": request_info.get("method", ""),
                "url": "",
                "body": "",
            }

            # Extract URL
            url = request_info.get("url", {})
            if isinstance(url, str):
                request_data["url"] = url
            elif isinstance(url, dict):
                request_data["url"] = url.get("raw", "")

            # Extract body
            body = request_info.get("body", {})
            if body:
                request_data["body"] = body.get("raw", "")

            # Extract response examples
            responses = item.get("response", [])
            request_data["responses"] = []
            for resp in responses:
                resp_data = {
                    "name": resp.get("name", ""),
                    "status": resp.get("status", ""),
                    "code": resp.get("code", 0),
                    "body": resp.get("body", ""),
                }
                request_data["responses"].append(resp_data)

            requests.append(request_data)

        return {
            "collection_name": collection_name,
            "total_requests": len(requests),
            "requests": requests,
        }
    except FileNotFoundError:
        raise Exception(f"Collection file not found: {file_path}")
    except json.JSONDecodeError as e:
        raise Exception(f"Invalid JSON in collection file: {str(e)}")
    except Exception as e:
        raise Exception(f"Error reading collection: {str(e)}")


def convert_collection_ims_to_json(file_path: str, output_path: Optional[str] = None,
                                    config_path: Optional[str] = None) -> dict:
    """
    Read a Postman collection, find IMS format strings in request/response bodies,
    convert them to JSON format, update the collection, and save it.
    """
    config = load_config(config_path) if config_path else None

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        updated_collection = copy.deepcopy(data)
        conversion_results = []

        items = updated_collection.get("item", [])
        for item in items:
            item_name = item.get("name", "")

            # Process request body
            request = item.get("request", {})
            body = request.get("body", {})
            if body and body.get("raw", ""):
                raw_body = body["raw"]
                # Use request name as primary endpoint identifier for matching
                endpoint_id = item_name

                converted = _try_convert_ims_body(raw_body, config, endpoint_id)
                if converted["was_converted"]:
                    body["raw"] = json.dumps(converted["json_data"], indent=2)
                    # Update content type to application/json if mode is raw
                    if body.get("options", {}).get("raw", {}).get("language") != "json":
                        body.setdefault("options", {}).setdefault("raw", {})["language"] = "json"
                    conversion_results.append({
                        "item": item_name,
                        "location": "request_body",
                        "status": "converted",
                        "original_ims": raw_body.strip(),
                        "converted_json": converted["json_data"],
                    })

            # Process response bodies
            responses = item.get("response", [])
            for resp in responses:
                resp_body = resp.get("body", "")
                if resp_body:
                    converted = _try_convert_ims_body(resp_body, config, endpoint_id)
                    if converted["was_converted"]:
                        resp["body"] = json.dumps(converted["json_data"], indent=2)
                        conversion_results.append({
                            "item": item_name,
                            "location": f"response_{resp.get('name', 'unknown')}",
                            "status": "converted",
                            "original_ims": resp_body.strip(),
                            "converted_json": converted["json_data"],
                        })

        # Save updated collection with timestamp in filename
        if output_path:
            save_path = output_path
        else:
            base, ext = os.path.splitext(file_path)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = f"{base}_{timestamp}{ext}"

        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(updated_collection, f, indent=2)

        return {
            "status": "success",
            "input_file": file_path,
            "output_file": save_path,
            "total_conversions": len(conversion_results),
            "conversions": conversion_results,
        }

    except FileNotFoundError:
        raise Exception(f"Collection file not found: {file_path}")
    except json.JSONDecodeError as e:
        raise Exception(f"Invalid JSON in collection file: {str(e)}")
    except Exception as e:
        raise Exception(f"Error converting collection: {str(e)}")


def _try_convert_ims_body(raw_body: str, config: Optional[dict] = None, endpoint: Optional[str] = None) -> dict:
    """
    Attempt to detect if a raw body string is in IMS fixed-length format
    and convert it to JSON. Handles both plain IMS strings and JSON arrays
    of IMS strings (bodyFormat: 'jsonArray').
    Returns a dict indicating whether conversion happened.
    """
    body = raw_body.strip()

    # Check if this endpoint uses jsonArray body format
    body_format = _get_endpoint_body_format(config, endpoint)

    if body_format == "jsonArray" and body.startswith("["):
        # Body is a JSON array of IMS strings
        try:
            ims_array = json.loads(body)
            if isinstance(ims_array, list) and all(isinstance(s, str) for s in ims_array):
                parsed = parse_array_ims_to_json(ims_array, config, endpoint)
                if "error" not in parsed:
                    non_empty = sum(1 for k, v in parsed.items() if isinstance(v, str) and v)
                    if non_empty >= 2:
                        return {"was_converted": True, "json_data": parsed}
        except json.JSONDecodeError:
            pass
        return {"was_converted": False, "json_data": None}

    # Skip if it's already JSON (object or array)
    if body.startswith("{") or body.startswith("["):
        try:
            json.loads(body)
            return {"was_converted": False, "json_data": None}
        except json.JSONDecodeError:
            pass

    if len(body) < 10:
        return {"was_converted": False, "json_data": None}

    # Try to parse as plain IMS string
    parsed = parse_ims_to_json(body, config, endpoint)
    if "error" in parsed:
        return {"was_converted": False, "json_data": None}

    # Check if at least some fields have non-empty values
    non_empty = sum(1 for k, v in parsed.items() if isinstance(v, str) and v)
    if non_empty >= 2:
        return {"was_converted": True, "json_data": parsed}

    return {"was_converted": False, "json_data": None}
