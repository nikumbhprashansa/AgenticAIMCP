from fastmcp import FastMCP
from typing import Annotated, Optional

from pydantic import Field

from formatexchange_lib import (
    read_postman_collection,
    parse_ims_to_json,
    json_to_ims,
    get_ims_field_definitions,
    convert_collection_ims_to_json,
    load_config,
    convert_collection_with_inline_config,
)

mcp = FastMCP("FileExchange MCP Server",
              version="0.1.0",
              include_tags={"public"})


@mcp.tool(description="Read a Postman collection file and return structured data including request names, methods, URLs, bodies, and responses",
          tags={"public"})
def read_collection(
        file_path: Annotated[str, Field(description="Absolute path to the Postman collection JSON file")]
) -> dict:
    return read_postman_collection(file_path)


@mcp.tool(description="Parse a fixed-length IMS string into a structured JSON object. "
                       "Uses default TMS Victors field mapping unless a config_path to a custom IMS config JSON is provided.",
          tags={"public"})
def parse_ims(
        ims_string: Annotated[str, Field(description="The fixed-length IMS format string to parse into JSON")],
        config_path: Annotated[Optional[str], Field(description="Absolute path to IMS config JSON file. If not provided, uses default TMS Victors field mapping")] = None,
) -> dict:
    config = load_config(config_path) if config_path else None
    return parse_ims_to_json(ims_string, config)


@mcp.tool(description="Convert a JSON object back into a fixed-length IMS string. "
                       "Uses default field mapping unless a config_path is provided.",
          tags={"public"})
def convert_json_to_ims(
        json_data: Annotated[dict, Field(description="JSON dictionary with IMS field names as keys")],
        config_path: Annotated[Optional[str], Field(description="Absolute path to IMS config JSON file. If not provided, uses default field mapping")] = None,
) -> dict:
    config = load_config(config_path) if config_path else None
    ims_string = json_to_ims(json_data, config)
    return {
        "ims_string": ims_string,
        "length": len(ims_string),
    }


@mcp.tool(description="Get the IMS field definitions including field names, formats, lengths, offsets, and descriptions. "
                       "Uses default field mapping unless a config_path is provided.",
          tags={"public"})
def get_ims_fields(
        config_path: Annotated[Optional[str], Field(description="Absolute path to IMS config JSON file. If not provided, uses default field mapping")] = None,
) -> dict:
    config = load_config(config_path) if config_path else None
    definitions = get_ims_field_definitions(config)
    return {
        "config_name": config.get("name", "Default") if config else "Default TMS Victors",
        "total_fields": len(definitions),
        "total_length": sum(d["length"] for d in definitions),
        "fields": definitions,
    }


@mcp.tool(description="Read a Postman collection, detect IMS format strings in request/response bodies, "
                       "convert them to JSON format, update the collection, and save it. "
                       "Provide a config_path to use a custom IMS field mapping, otherwise uses default.",
          tags={"public"})
def convert_collection(
        file_path: Annotated[str, Field(description="Absolute path to the Postman collection JSON file")],
        output_path: Annotated[Optional[str], Field(description="Absolute path to save the updated collection. If not provided, saves with a timestamp suffix")] = None,
        config_path: Annotated[Optional[str], Field(description="Absolute path to IMS config JSON file. If not provided, uses default TMS Victors field mapping")] = None,
) -> dict:
    return convert_collection_ims_to_json(file_path, output_path, config_path)


@mcp.tool(description="Convert any Postman collection from IMS format to JSON by providing the field mapping inline. "
                       "No config file needed. Pass the IMS field structure and desired JSON field names directly. "
                       "Works for any collection with any IMS structure.",
          tags={"public"})
def convert_any_collection(
        file_path: Annotated[str, Field(description="Absolute path to the Postman collection JSON file")],
        fields: Annotated[list, Field(description="List of field mappings in order. Each item is a dict with: "
                                                   "'imsField' (IMS field name like #DD-STN-ABBR), "
                                                   "'jsonField' (output JSON key like stationAbbr), "
                                                   "'length' (int, number of characters in IMS string). "
                                                   "Example: [{'imsField':'#DD-STN-ABBR','jsonField':'stationAbbr','length':6}, ...]")],
        repeating_group_name: Annotated[Optional[str], Field(description="JSON key for the repeating group array (e.g., 'equipmentDetailList'). Omit if no repeating group")] = None,
        repeating_fields: Annotated[Optional[list], Field(description="List of repeating group field mappings. Same format as fields: [{'imsField':'TRACK-NUMBER','jsonField':'trackNumber','length':4}, ...]")] = None,
        output_path: Annotated[Optional[str], Field(description="Absolute path to save the updated collection. If not provided, saves with a timestamp suffix")] = None,
) -> dict:
    return convert_collection_with_inline_config(file_path, fields, repeating_group_name, repeating_fields, output_path)


if __name__ == "__main__":
    mcp.run(transport="http", host="127.0.0.1", port=8002)
