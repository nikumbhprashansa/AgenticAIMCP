import openpyxl
from typing import Optional


def read_excel_file(file_path: str, sheet_name: Optional[str] = None) -> dict:
    """Read an Excel file and return workbook metadata and sheet names."""
    try:
        workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        sheets = workbook.sheetnames
        active_sheet = workbook.active.title if workbook.active else sheets[0]
        workbook.close()

        return {
            "file_path": file_path,
            "sheet_names": sheets,
            "active_sheet": active_sheet,
            "total_sheets": len(sheets),
        }
    except Exception as e:
        raise Exception(f"Error reading Excel file: {str(e)}")


def read_sheet_data(file_path: str, sheet_name: Optional[str] = None,
                    start_row: int = 1, max_rows: Optional[int] = None) -> dict:
    """Read data from a specific sheet in an Excel file."""
    try:
        workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                workbook.close()
                raise Exception(f"Sheet '{sheet_name}' not found. Available sheets: {workbook.sheetnames}")
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.active

        rows = []
        headers = []
        for row_idx, row in enumerate(sheet.iter_rows(min_row=start_row, values_only=True), start=start_row):
            row_data = [str(cell) if cell is not None else "" for cell in row]
            if row_idx == start_row:
                headers = row_data
            else:
                rows.append(row_data)
            if max_rows and (row_idx - start_row) >= max_rows:
                break

        workbook.close()

        return {
            "file_path": file_path,
            "sheet_name": sheet.title,
            "headers": headers,
            "rows": rows,
            "total_rows": len(rows),
        }
    except Exception as e:
        raise Exception(f"Error reading sheet data: {str(e)}")


def get_cell_value(file_path: str, cell_reference: str,
                   sheet_name: Optional[str] = None) -> dict:
    """Get the value of a specific cell in an Excel file."""
    try:
        workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                workbook.close()
                raise Exception(f"Sheet '{sheet_name}' not found. Available sheets: {workbook.sheetnames}")
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.active

        cell = sheet[cell_reference]
        value = cell.value
        workbook.close()

        return {
            "file_path": file_path,
            "sheet_name": sheet.title,
            "cell": cell_reference,
            "value": str(value) if value is not None else "",
        }
    except Exception as e:
        raise Exception(f"Error reading cell value: {str(e)}")


def search_in_sheet(file_path: str, search_text: str,
                    sheet_name: Optional[str] = None) -> dict:
    """Search for a text value across all cells in a sheet."""
    try:
        workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                workbook.close()
                raise Exception(f"Sheet '{sheet_name}' not found. Available sheets: {workbook.sheetnames}")
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.active

        matches = []
        for row_idx, row in enumerate(sheet.iter_rows(values_only=False), start=1):
            for cell in row:
                if cell.value is not None and search_text.lower() in str(cell.value).lower():
                    matches.append({
                        "cell": cell.coordinate,
                        "row": cell.row,
                        "column": cell.column,
                        "value": str(cell.value),
                    })

        workbook.close()

        return {
            "file_path": file_path,
            "sheet_name": sheet.title,
            "search_text": search_text,
            "matches": matches,
            "total_matches": len(matches),
        }
    except Exception as e:
        raise Exception(f"Error searching in sheet: {str(e)}")


def get_sheet_summary(file_path: str, sheet_name: Optional[str] = None) -> dict:
    """Get summary information about a sheet (dimensions, row/column count)."""
    try:
        workbook = openpyxl.load_workbook(file_path, read_only=True, data_only=True)

        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                workbook.close()
                raise Exception(f"Sheet '{sheet_name}' not found. Available sheets: {workbook.sheetnames}")
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.active

        dimensions = sheet.dimensions
        min_row = sheet.min_row
        max_row = sheet.max_row
        min_col = sheet.min_column
        max_col = sheet.max_column

        workbook.close()

        return {
            "file_path": file_path,
            "sheet_name": sheet.title,
            "dimensions": dimensions,
            "min_row": min_row,
            "max_row": max_row,
            "min_column": min_col,
            "max_column": max_col,
            "total_rows": max_row - min_row + 1 if max_row and min_row else 0,
            "total_columns": max_col - min_col + 1 if max_col and min_col else 0,
        }
    except Exception as e:
        raise Exception(f"Error getting sheet summary: {str(e)}")


if __name__ == "__main__":
    # Quick test
    import sys
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        info = read_excel_file(file_path)
        print(f"Excel file: {file_path}")
        for k, v in info.items():
            print(f"  {k}: {v}")
