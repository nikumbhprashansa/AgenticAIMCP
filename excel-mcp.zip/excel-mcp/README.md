# excel-mcp
Excel MCP Server

## Tools

| Tool | Description |
|------|-------------|
| `get_excel_info` | Returns workbook metadata (sheet names, active sheet) |
| `get_sheet_data` | Reads headers and rows from a sheet |
| `get_excel_cell_value` | Gets the value of a specific cell |
| `search_excel` | Searches for text across all cells in a sheet |
| `get_excel_sheet_summary` | Gets sheet dimensions and row/column counts |

## Setup

```bash
pip install -r requirements.txt
```

## Run

```bash
python excel_mcp.py
```
