from fastmcp import FastMCP
from typing import Annotated, Optional

from pydantic import Field

from excel_lib import (
    read_excel_file,
    read_sheet_data,
    get_cell_value,
    search_in_sheet,
    get_sheet_summary,
)

mcp = FastMCP("Excel MCP Server",
              version="0.1.0",
              include_tags={"public"})


@mcp.tool(description="Reads an Excel file and returns workbook metadata including sheet names and active sheet",
          tags={"public"})
def get_excel_info(
        file_path: Annotated[str, Field(description="Absolute path to the Excel file (.xlsx)")]
) -> dict:
    return read_excel_file(file_path)


@mcp.tool(description="Reads data from a specific sheet in an Excel file. Returns headers and rows. "
                       "By default reads from the active sheet starting at row 1.",
          tags={"public"})
def get_sheet_data(
        file_path: Annotated[str, Field(description="Absolute path to the Excel file (.xlsx)")],
        sheet_name: Annotated[Optional[str], Field(description="Name of the sheet to read. If not provided, reads the active sheet")] = None,
        start_row: Annotated[int, Field(description="Row number to start reading from (1-based). Default is 1")] = 1,
        max_rows: Annotated[Optional[int], Field(description="Maximum number of rows to read. If not provided, reads all rows")] = None,
) -> dict:
    return read_sheet_data(file_path, sheet_name, start_row, max_rows)


@mcp.tool(description="Gets the value of a specific cell in an Excel file (e.g., 'A1', 'B5')",
          tags={"public"})
def get_excel_cell_value(
        file_path: Annotated[str, Field(description="Absolute path to the Excel file (.xlsx)")],
        cell_reference: Annotated[str, Field(description="Cell reference (e.g., 'A1', 'B5', 'C10')")],
        sheet_name: Annotated[Optional[str], Field(description="Name of the sheet. If not provided, uses the active sheet")] = None,
) -> dict:
    return get_cell_value(file_path, cell_reference, sheet_name)


@mcp.tool(description="Searches for a text value across all cells in a sheet and returns matching cells",
          tags={"public"})
def search_excel(
        file_path: Annotated[str, Field(description="Absolute path to the Excel file (.xlsx)")],
        search_text: Annotated[str, Field(description="Text to search for (case-insensitive)")],
        sheet_name: Annotated[Optional[str], Field(description="Name of the sheet to search. If not provided, searches the active sheet")] = None,
) -> dict:
    return search_in_sheet(file_path, search_text, sheet_name)


@mcp.tool(description="Gets summary information about a sheet including dimensions, row count, and column count",
          tags={"public"})
def get_excel_sheet_summary(
        file_path: Annotated[str, Field(description="Absolute path to the Excel file (.xlsx)")],
        sheet_name: Annotated[Optional[str], Field(description="Name of the sheet. If not provided, uses the active sheet")] = None,
) -> dict:
    return get_sheet_summary(file_path, sheet_name)


if __name__ == "__main__":
    mcp.run(transport="http", host="127.0.0.1", port=8001)
