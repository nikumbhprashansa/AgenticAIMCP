import os
import sys
from excel_lib import read_sheet_data


FILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "testdata.xlsx")


def test_read_sheet_data():
    """Test reading data from testdata.xls."""
    print(f"Reading file: {FILE_PATH}")
    result = read_sheet_data(FILE_PATH)

    print(f"Sheet: {result['sheet_name']}")
    print(f"Headers: {result['headers']}")
    print(f"Total rows: {result['total_rows']}")
    print("\nFirst 10 rows:")
    for i, row in enumerate(result["rows"][:10]):
        print(f"  Row {i + 1}: {row}")
    print("\nPASSED: test_read_sheet_data")


def test_read_with_max_rows():
    """Test reading testdata.xls with max_rows limit."""
    result = read_sheet_data(FILE_PATH, max_rows=3)

    assert len(result["rows"]) <= 2, f"Expected at most 2 data rows, got {len(result['rows'])}"
    print(f"Headers: {result['headers']}")
    print(f"Rows returned: {result['total_rows']}")
    print("PASSED: test_read_with_max_rows")


def test_read_invalid_sheet_name():
    """Test that reading a non-existent sheet raises an error."""
    try:
        read_sheet_data(FILE_PATH, sheet_name="NonExistent")
        assert False, "Should have raised an exception"
    except Exception as e:
        assert "not found" in str(e)
        print("PASSED: test_read_invalid_sheet_name")


def test_read_invalid_file_path():
    """Test that reading a non-existent file raises an error."""
    try:
        read_sheet_data("non_existent_file.xlsx")
        assert False, "Should have raised an exception"
    except Exception as e:
        assert "Error reading sheet data" in str(e)
        print("PASSED: test_read_invalid_file_path")


if __name__ == "__main__":
    test_read_sheet_data()
    print()
    test_read_with_max_rows()
    print()
    test_read_invalid_sheet_name()
    print()
    test_read_invalid_file_path()
    print("\nAll tests passed!")


